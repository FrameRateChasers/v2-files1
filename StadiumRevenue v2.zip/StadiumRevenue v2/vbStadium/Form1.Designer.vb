﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.lblClassA = New System.Windows.Forms.Label()
        Me.lblClassB = New System.Windows.Forms.Label()
        Me.lblClassC = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.lblClassAOutput = New System.Windows.Forms.Label()
        Me.lblClassBOutput = New System.Windows.Forms.Label()
        Me.lblClassCOutput = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.lblTotalRev = New System.Windows.Forms.Label()
        Me.lblCA = New System.Windows.Forms.Label()
        Me.lblCC = New System.Windows.Forms.Label()
        Me.lblCB = New System.Windows.Forms.Label()
        Me.lblOutputRev = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnCalc
        '
        Me.btnCalc.BackColor = System.Drawing.Color.DarkOrange
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(12, 344)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(193, 87)
        Me.btnCalc.TabIndex = 0
        Me.btnCalc.Text = "CALCULATE REVENUE"
        Me.btnCalc.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.BackColor = System.Drawing.Color.DarkOrange
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(12, 251)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(193, 87)
        Me.btnClear.TabIndex = 1
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = False
        '
        'btnExit
        '
        Me.btnExit.BackColor = System.Drawing.Color.DarkOrange
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(273, 344)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(193, 87)
        Me.btnExit.TabIndex = 2
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Gold
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(12, 30)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(143, 24)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "TICKETS SOLD"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Gold
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(24, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(264, 48)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "ENTER NUMBER OF TICKET" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "SOLD FOR EACH CLASS"
        '
        'lblClassA
        '
        Me.lblClassA.AutoSize = True
        Me.lblClassA.BackColor = System.Drawing.Color.Gold
        Me.lblClassA.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassA.Location = New System.Drawing.Point(12, 132)
        Me.lblClassA.Name = "lblClassA"
        Me.lblClassA.Size = New System.Drawing.Size(88, 24)
        Me.lblClassA.TabIndex = 5
        Me.lblClassA.Text = "CLASS A"
        '
        'lblClassB
        '
        Me.lblClassB.AutoSize = True
        Me.lblClassB.BackColor = System.Drawing.Color.Gold
        Me.lblClassB.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassB.Location = New System.Drawing.Point(13, 171)
        Me.lblClassB.Name = "lblClassB"
        Me.lblClassB.Size = New System.Drawing.Size(87, 24)
        Me.lblClassB.TabIndex = 6
        Me.lblClassB.Text = "CLASS B"
        '
        'lblClassC
        '
        Me.lblClassC.AutoSize = True
        Me.lblClassC.BackColor = System.Drawing.Color.Gold
        Me.lblClassC.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassC.Location = New System.Drawing.Point(13, 207)
        Me.lblClassC.Name = "lblClassC"
        Me.lblClassC.Size = New System.Drawing.Size(88, 24)
        Me.lblClassC.TabIndex = 7
        Me.lblClassC.Text = "CLASS C"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.BackColor = System.Drawing.Color.Yellow
        Me.Label6.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(330, 67)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(225, 24)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "REVENUE GENERATED"
        '
        'lblClassAOutput
        '
        Me.lblClassAOutput.AutoSize = True
        Me.lblClassAOutput.BackColor = System.Drawing.Color.Yellow
        Me.lblClassAOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassAOutput.Location = New System.Drawing.Point(330, 116)
        Me.lblClassAOutput.Name = "lblClassAOutput"
        Me.lblClassAOutput.Size = New System.Drawing.Size(88, 24)
        Me.lblClassAOutput.TabIndex = 9
        Me.lblClassAOutput.Text = "CLASS A"
        '
        'lblClassBOutput
        '
        Me.lblClassBOutput.AutoSize = True
        Me.lblClassBOutput.BackColor = System.Drawing.Color.Yellow
        Me.lblClassBOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassBOutput.Location = New System.Drawing.Point(330, 157)
        Me.lblClassBOutput.Name = "lblClassBOutput"
        Me.lblClassBOutput.Size = New System.Drawing.Size(87, 24)
        Me.lblClassBOutput.TabIndex = 10
        Me.lblClassBOutput.Text = "CLASS B"
        '
        'lblClassCOutput
        '
        Me.lblClassCOutput.AutoSize = True
        Me.lblClassCOutput.BackColor = System.Drawing.Color.Yellow
        Me.lblClassCOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassCOutput.Location = New System.Drawing.Point(330, 196)
        Me.lblClassCOutput.Name = "lblClassCOutput"
        Me.lblClassCOutput.Size = New System.Drawing.Size(88, 24)
        Me.lblClassCOutput.TabIndex = 11
        Me.lblClassCOutput.Text = "CLASS C"
        '
        'TextBox1
        '
        Me.TextBox1.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox1.Location = New System.Drawing.Point(124, 132)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(100, 29)
        Me.TextBox1.TabIndex = 12
        '
        'TextBox2
        '
        Me.TextBox2.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox2.Location = New System.Drawing.Point(124, 171)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 29)
        Me.TextBox2.TabIndex = 13
        '
        'TextBox3
        '
        Me.TextBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.TextBox3.Location = New System.Drawing.Point(124, 207)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 29)
        Me.TextBox3.TabIndex = 14
        '
        'lblTotalRev
        '
        Me.lblTotalRev.AutoSize = True
        Me.lblTotalRev.BackColor = System.Drawing.Color.Yellow
        Me.lblTotalRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalRev.Location = New System.Drawing.Point(245, 242)
        Me.lblTotalRev.Name = "lblTotalRev"
        Me.lblTotalRev.Size = New System.Drawing.Size(184, 24)
        Me.lblTotalRev.TabIndex = 19
        Me.lblTotalRev.Text = "TOTOAL REVENUE"
        '
        'lblCA
        '
        Me.lblCA.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCA.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCA.ForeColor = System.Drawing.Color.Yellow
        Me.lblCA.Location = New System.Drawing.Point(453, 115)
        Me.lblCA.Name = "lblCA"
        Me.lblCA.Size = New System.Drawing.Size(128, 25)
        Me.lblCA.TabIndex = 20
        '
        'lblCC
        '
        Me.lblCC.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCC.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCC.ForeColor = System.Drawing.Color.Yellow
        Me.lblCC.Location = New System.Drawing.Point(453, 195)
        Me.lblCC.Name = "lblCC"
        Me.lblCC.Size = New System.Drawing.Size(128, 25)
        Me.lblCC.TabIndex = 21
        '
        'lblCB
        '
        Me.lblCB.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblCB.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCB.ForeColor = System.Drawing.Color.Yellow
        Me.lblCB.Location = New System.Drawing.Point(453, 156)
        Me.lblCB.Name = "lblCB"
        Me.lblCB.Size = New System.Drawing.Size(128, 25)
        Me.lblCB.TabIndex = 22
        '
        'lblOutputRev
        '
        Me.lblOutputRev.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutputRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblOutputRev.ForeColor = System.Drawing.Color.Yellow
        Me.lblOutputRev.Location = New System.Drawing.Point(453, 242)
        Me.lblOutputRev.Name = "lblOutputRev"
        Me.lblOutputRev.Size = New System.Drawing.Size(128, 25)
        Me.lblOutputRev.TabIndex = 23
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.MenuHighlight
        Me.ClientSize = New System.Drawing.Size(600, 452)
        Me.Controls.Add(Me.lblOutputRev)
        Me.Controls.Add(Me.lblCB)
        Me.Controls.Add(Me.lblCC)
        Me.Controls.Add(Me.lblCA)
        Me.Controls.Add(Me.lblTotalRev)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.TextBox2)
        Me.Controls.Add(Me.TextBox1)
        Me.Controls.Add(Me.lblClassCOutput)
        Me.Controls.Add(Me.lblClassBOutput)
        Me.Controls.Add(Me.lblClassAOutput)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.lblClassC)
        Me.Controls.Add(Me.lblClassB)
        Me.Controls.Add(Me.lblClassA)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "Form1"
        Me.Text = "Stadium Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnCalc As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnExit As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents lblClassA As Label
    Friend WithEvents lblClassB As Label
    Friend WithEvents lblClassC As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents lblClassAOutput As Label
    Friend WithEvents lblClassBOutput As Label
    Friend WithEvents lblClassCOutput As Label
    Friend WithEvents TextBox1 As TextBox
    Friend WithEvents TextBox2 As TextBox
    Friend WithEvents TextBox3 As TextBox
    Friend WithEvents lblTotalRev As Label
    Friend WithEvents lblCA As Label
    Friend WithEvents lblCC As Label
    Friend WithEvents lblCB As Label
    Friend WithEvents lblOutputRev As Label
End Class
