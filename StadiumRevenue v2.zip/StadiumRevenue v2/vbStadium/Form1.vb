﻿Public Class Form1



    'THESE ARE CONSTANT VARIBLES   
    Private Const PRICE_OF_A As Integer = 15
    Private Const PRICE_OF_B As Integer = 12
    Private Const PRICE_OF_C As Integer = 9

    'THESE ARE PUBLIC VARIBLES THAT WILL STORE RESULTS
    Public intCA, intCB, intCC, intResults, intResultA, intResultB, intResultC As Integer



    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        If TextBox1.Text = "" Or TextBox2.Text = "" Or TextBox3.Text = "" Then
            MessageBox.Show("please do not leave input box empty")
        Else
            MathCalculations()
        End If

    End Sub
    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearAllInputsOutputs()
    End Sub

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub



    Public Sub MathCalculations()

        'first converts textbox input into integer 
        'then it is stored in global variables above

        If Not Short.TryParse(TextBox1.Text, intCA) Or Not Short.TryParse(TextBox2.Text, intCB) Or Not Short.TryParse(TextBox3.Text, intCC) Then
            MessageBox.Show("please enter a whole number")
            ClearAllInputsOutputs()
        Else
            Short.TryParse(TextBox1.Text, intCA)
            Short.TryParse(TextBox2.Text, intCB)
            Short.TryParse(TextBox3.Text, intCC)

            'mulitply a VARIABLE And CONSTANT
            'then stores the result into another set of global varible
            intResultA = intCA * PRICE_OF_A
            intResultB = intCB * PRICE_OF_B
            intResultC = intCC * PRICE_OF_C

            'global varible is then converted into string with currency format
            'and is store in label and displayed as text
            lblCA.Text = intResultA.ToString("c")
            lblCB.Text = intResultB.ToString("c")
            lblCC.Text = intResultC.ToString("c")

            'add all the results and display all calucation 
            intResults = intResultA + intResultB + intResultC
            lblOutputRev.Text = intResults.ToString("c")

        End If



    End Sub
    Public Sub ClearAllInputsOutputs()
        lblCA.Text = ""
        lblCB.Text = ""
        lblCC.Text = ""
        lblOutputRev.Text = ""
        TextBox1.Text = ""
        TextBox2.Text = ""
        TextBox3.Text = ""
    End Sub
End Class