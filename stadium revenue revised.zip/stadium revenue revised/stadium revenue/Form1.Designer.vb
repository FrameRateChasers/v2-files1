﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.lblClass2 = New System.Windows.Forms.Label()
        Me.lblClass3 = New System.Windows.Forms.Label()
        Me.lblClass1 = New System.Windows.Forms.Label()
        Me.lblTotalRev = New System.Windows.Forms.Label()
        Me.txt3 = New System.Windows.Forms.TextBox()
        Me.txt2 = New System.Windows.Forms.TextBox()
        Me.txt1 = New System.Windows.Forms.TextBox()
        Me.lblClassCOutput = New System.Windows.Forms.Label()
        Me.lblClassBOutput = New System.Windows.Forms.Label()
        Me.lblClassAOutput = New System.Windows.Forms.Label()
        Me.Label88 = New System.Windows.Forms.Label()
        Me.lblClassC = New System.Windows.Forms.Label()
        Me.lblClassB = New System.Windows.Forms.Label()
        Me.lblClassA = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCalc = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblTotal.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotal.Location = New System.Drawing.Point(408, 235)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(138, 25)
        Me.lblTotal.TabIndex = 43
        '
        'lblClass2
        '
        Me.lblClass2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClass2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClass2.Location = New System.Drawing.Point(350, 142)
        Me.lblClass2.Name = "lblClass2"
        Me.lblClass2.Size = New System.Drawing.Size(128, 25)
        Me.lblClass2.TabIndex = 42
        '
        'lblClass3
        '
        Me.lblClass3.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClass3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClass3.Location = New System.Drawing.Point(350, 194)
        Me.lblClass3.Name = "lblClass3"
        Me.lblClass3.Size = New System.Drawing.Size(128, 25)
        Me.lblClass3.TabIndex = 41
        '
        'lblClass1
        '
        Me.lblClass1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblClass1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClass1.Location = New System.Drawing.Point(350, 93)
        Me.lblClass1.Name = "lblClass1"
        Me.lblClass1.Size = New System.Drawing.Size(128, 25)
        Me.lblClass1.TabIndex = 40
        '
        'lblTotalRev
        '
        Me.lblTotalRev.AutoSize = True
        Me.lblTotalRev.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTotalRev.Location = New System.Drawing.Point(274, 243)
        Me.lblTotalRev.Name = "lblTotalRev"
        Me.lblTotalRev.Size = New System.Drawing.Size(119, 13)
        Me.lblTotalRev.TabIndex = 39
        Me.lblTotalRev.Text = "TOTOAL REVENUE"
        '
        'txt3
        '
        Me.txt3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt3.Location = New System.Drawing.Point(91, 228)
        Me.txt3.Name = "txt3"
        Me.txt3.Size = New System.Drawing.Size(100, 20)
        Me.txt3.TabIndex = 38
        '
        'txt2
        '
        Me.txt2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt2.Location = New System.Drawing.Point(90, 179)
        Me.txt2.Name = "txt2"
        Me.txt2.Size = New System.Drawing.Size(100, 20)
        Me.txt2.TabIndex = 37
        '
        'txt1
        '
        Me.txt1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txt1.Location = New System.Drawing.Point(90, 130)
        Me.txt1.Name = "txt1"
        Me.txt1.Size = New System.Drawing.Size(100, 20)
        Me.txt1.TabIndex = 36
        '
        'lblClassCOutput
        '
        Me.lblClassCOutput.AutoSize = True
        Me.lblClassCOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassCOutput.Location = New System.Drawing.Point(274, 194)
        Me.lblClassCOutput.Name = "lblClassCOutput"
        Me.lblClassCOutput.Size = New System.Drawing.Size(58, 13)
        Me.lblClassCOutput.TabIndex = 35
        Me.lblClassCOutput.Text = "CLASS C"
        '
        'lblClassBOutput
        '
        Me.lblClassBOutput.AutoSize = True
        Me.lblClassBOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassBOutput.Location = New System.Drawing.Point(274, 142)
        Me.lblClassBOutput.Name = "lblClassBOutput"
        Me.lblClassBOutput.Size = New System.Drawing.Size(58, 13)
        Me.lblClassBOutput.TabIndex = 34
        Me.lblClassBOutput.Text = "CLASS B"
        '
        'lblClassAOutput
        '
        Me.lblClassAOutput.AutoSize = True
        Me.lblClassAOutput.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassAOutput.Location = New System.Drawing.Point(274, 93)
        Me.lblClassAOutput.Name = "lblClassAOutput"
        Me.lblClassAOutput.Size = New System.Drawing.Size(58, 13)
        Me.lblClassAOutput.TabIndex = 33
        Me.lblClassAOutput.Text = "CLASS A"
        '
        'Label88
        '
        Me.Label88.AutoSize = True
        Me.Label88.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label88.Location = New System.Drawing.Point(315, 46)
        Me.Label88.Name = "Label88"
        Me.Label88.Size = New System.Drawing.Size(146, 13)
        Me.Label88.TabIndex = 32
        Me.Label88.Text = "REVENUE GENERATED"
        '
        'lblClassC
        '
        Me.lblClassC.AutoSize = True
        Me.lblClassC.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassC.Location = New System.Drawing.Point(13, 235)
        Me.lblClassC.Name = "lblClassC"
        Me.lblClassC.Size = New System.Drawing.Size(58, 13)
        Me.lblClassC.TabIndex = 31
        Me.lblClassC.Text = "CLASS C"
        '
        'lblClassB
        '
        Me.lblClassB.AutoSize = True
        Me.lblClassB.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassB.Location = New System.Drawing.Point(13, 185)
        Me.lblClassB.Name = "lblClassB"
        Me.lblClassB.Size = New System.Drawing.Size(58, 13)
        Me.lblClassB.TabIndex = 30
        Me.lblClassB.Text = "CLASS B"
        '
        'lblClassA
        '
        Me.lblClassA.AutoSize = True
        Me.lblClassA.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblClassA.Location = New System.Drawing.Point(13, 128)
        Me.lblClassA.Name = "lblClassA"
        Me.lblClassA.Size = New System.Drawing.Size(58, 13)
        Me.lblClassA.TabIndex = 29
        Me.lblClassA.Text = "CLASS A"
        '
        'Label78
        '
        Me.Label78.AutoSize = True
        Me.Label78.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label78.Location = New System.Drawing.Point(31, 66)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(174, 26)
        Me.Label78.TabIndex = 28
        Me.Label78.Text = "ENTER NUMBER OF TICKET" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "SOLD FOR EACH CLASS"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(19, 29)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(96, 13)
        Me.Label12.TabIndex = 27
        Me.Label12.Text = "TICKETS SOLD"
        '
        'btnExit
        '
        Me.btnExit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExit.Location = New System.Drawing.Point(453, 279)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(93, 47)
        Me.btnExit.TabIndex = 26
        Me.btnExit.Text = "EXIT"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(226, 279)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(93, 47)
        Me.btnClear.TabIndex = 25
        Me.btnClear.Text = "CLEAR"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCalc
        '
        Me.btnCalc.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnCalc.Location = New System.Drawing.Point(16, 279)
        Me.btnCalc.Name = "btnCalc"
        Me.btnCalc.Size = New System.Drawing.Size(93, 47)
        Me.btnCalc.TabIndex = 24
        Me.btnCalc.Text = "CALCULATE REVENUE"
        Me.btnCalc.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(558, 359)
        Me.Controls.Add(Me.lblTotal)
        Me.Controls.Add(Me.lblClass2)
        Me.Controls.Add(Me.lblClass3)
        Me.Controls.Add(Me.lblClass1)
        Me.Controls.Add(Me.lblTotalRev)
        Me.Controls.Add(Me.txt3)
        Me.Controls.Add(Me.txt2)
        Me.Controls.Add(Me.txt1)
        Me.Controls.Add(Me.lblClassCOutput)
        Me.Controls.Add(Me.lblClassBOutput)
        Me.Controls.Add(Me.lblClassAOutput)
        Me.Controls.Add(Me.Label88)
        Me.Controls.Add(Me.lblClassC)
        Me.Controls.Add(Me.lblClassB)
        Me.Controls.Add(Me.lblClassA)
        Me.Controls.Add(Me.Label78)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalc)
        Me.Name = "Form1"
        Me.Text = "Stadium Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents lblTotal As Label
    Friend WithEvents lblClass2 As Label
    Friend WithEvents lblClass3 As Label
    Friend WithEvents lblClass1 As Label
    Friend WithEvents lblTotalRev As Label
    Friend WithEvents txt3 As TextBox
    Friend WithEvents txt2 As TextBox
    Friend WithEvents txt1 As TextBox
    Friend WithEvents lblClassCOutput As Label
    Friend WithEvents lblClassBOutput As Label
    Friend WithEvents lblClassAOutput As Label
    Friend WithEvents Label88 As Label
    Friend WithEvents lblClassC As Label
    Friend WithEvents lblClassB As Label
    Friend WithEvents lblClassA As Label
    Friend WithEvents Label78 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents btnExit As Button
    Friend WithEvents btnClear As Button
    Friend WithEvents btnCalc As Button
End Class
