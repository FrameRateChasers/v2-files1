﻿Public Class Form1

    Private Const PRICE_OF_CLASSA As Integer = 15
    Private Const PRICE_OF_CLASSB As Integer = 12
    Private Const PRICE_OF_CLASSC As Integer = 9


    Public intClassA, intClassB, intClassC, intTotalResults, intResultClassA, intResultClassB, intResultClassC As Integer

    Private Sub btnExit_Click(sender As Object, e As EventArgs) Handles btnExit.Click
        Me.Close()
    End Sub

    Private Sub btnClear_Click(sender As Object, e As EventArgs) Handles btnClear.Click
        ClearInputsSub()
    End Sub

    Private Sub btnCalc_Click(sender As Object, e As EventArgs) Handles btnCalc.Click
        doMathShit()
        MultiplyClassRev()
        AssignClassRevAndOutputTotal()
    End Sub


    Public Sub doMathShit()
        If Not Integer.TryParse(txt1.Text, intClassA) Or Not Integer.TryParse(txt2.Text, intClassB) Or Not Integer.TryParse(txt3.Text, intClassC) Then
            MsgBox("PLEASE ENTER NUMBERIC DIGIT", MsgBoxStyle.Critical)
        Else
            Integer.TryParse(txt1.Text, intClassA)
            Integer.TryParse(txt2.Text, intClassB)
            Integer.TryParse(txt3.Text, intClassC)
        End If
    End Sub
    Public Sub MultiplyClassRev()
        intResultClassA = intClassA * PRICE_OF_CLASSA
        intResultClassB = intClassA * PRICE_OF_CLASSB
        intResultClassC = intClassA * PRICE_OF_CLASSC
    End Sub
    Public Sub AssignClassRevAndOutputTotal()
        lblClass1.Text = intResultClassA.ToString("C")
        lblClass2.Text = intResultClassB.ToString("C")
        lblClass3.Text = intResultClassC.ToString("C")

        intTotalResults = intResultClassA + intResultClassB + intResultClassC
        lblTotal.Text = intTotalResults.ToString("c")
    End Sub
    Public Sub ClearInputsSub()
        txt1.Text = ""
        txt2.Text = ""
        txt3.Text = ""
        lblClass1.Text = ""
        lblClass2.Text = ""
        lblClass3.Text = ""
        lblTotal.Text = ""
    End Sub



End Class
