﻿Public Class Form1

    Dim dblMiles, dblGallons, dblTotal As Double
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnCalc.Click

        If txtGallons.Text = "" Or txtMiles.Text = "" Then
            MsgBox("PLEAE ENTER INPUTS")
            If Not Double.TryParse(txtGallons.Text, dblGallons) Or Not Double.TryParse(txtMiles.Text, dblMiles) Then
                MsgBox("please makes sure all inputs are numerical")
            End If
        Else
            DoMathCalculations()
        End If
    End Sub


    Public Sub DoMathCalculations()
        Double.TryParse(txtGallons.Text, dblGallons)
        Double.TryParse(txtMiles.Text, dblMiles)
        dblTotal = dblMiles / dblGallons
        lblMPGOutput.Text = dblTotal
    End Sub

End Class
